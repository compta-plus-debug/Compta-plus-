// Identifiants du projet Supabase (compta-plus-debug's Project)
// Où les retrouver : tableau de bord Supabase → Project Settings → API

export const SUPABASE_URL = "https://cnmmxpwlgovzbcfqaxqm.supabase.co";
export const SUPABASE_ANON_KEY = "sb_publishable_Ba1KJd2YY-eLaCy1FRECIA_C1DoyAjL";
