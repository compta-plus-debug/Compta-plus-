// Service worker minimal — mise en cache de l'app shell pour un fonctionnement hors-ligne.
// À placer à la racine du site déployé (même dossier que index.html).

const CACHE_NAME = "grand-livre-cache-v1";
const APP_SHELL = [
  "/",
  "/index.html",
  "/manifest.json",
  // Ajoutez ici les fichiers générés par votre build (ex: /assets/index.js, /assets/index.css)
];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k)))
    )
  );
  self.clients.claim();
});

// Stratégie : réseau d'abord, repli sur le cache si hors-ligne
self.addEventListener("fetch", (event) => {
  if (event.request.method !== "GET") return;
  event.respondWith(
    fetch(event.request)
      .then((response) => {
        const copy = response.clone();
        caches.open(CACHE_NAME).then((cache) => cache.put(event.request, copy));
        return response;
      })
      .catch(() => caches.match(event.request))
  );
});
