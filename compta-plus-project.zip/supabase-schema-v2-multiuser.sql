-- Schéma v2 : base de données PARTAGÉE entre plusieurs utilisateurs, avec rôles.
-- À exécuter dans Supabase → SQL Editor.
-- Remplace le schéma v1 (kv_store scindé par user_id) par un modèle "entreprise".

-- 1) Une entreprise = un espace de données partagé
create table if not exists public.companies (
  id uuid primary key default gen_random_uuid(),
  name text not null default 'Mon Entreprise',
  created_at timestamptz default now()
);

-- 2) Les membres d'une entreprise, avec leur rôle
--    user_id est NULL tant que la personne invitée ne s'est pas encore connectée une première fois
create table if not exists public.company_members (
  id uuid primary key default gen_random_uuid(),
  company_id uuid references public.companies(id) on delete cascade,
  email text not null,
  user_id uuid references auth.users(id) on delete set null,
  role text not null default 'Éditeur' check (role in ('Administrateur', 'Éditeur', 'Lecture seule')),
  created_at timestamptz default now(),
  unique (company_id, email)
);

-- 3) Le stockage clé-valeur, maintenant scindé par ENTREPRISE et non plus par utilisateur
create table if not exists public.kv_store (
  company_id uuid references public.companies(id) on delete cascade,
  key text not null,
  value text not null,
  updated_at timestamptz default now(),
  primary key (company_id, key)
);

alter table public.companies enable row level security;
alter table public.company_members enable row level security;
alter table public.kv_store enable row level security;

-- Un utilisateur voit les entreprises dont il est membre
create policy "Voir les entreprises dont on est membre"
on public.companies for select
using (
  id in (select company_id from public.company_members where user_id = auth.uid())
);

-- Un utilisateur voit les membres de ses propres entreprises
create policy "Voir les membres de son entreprise"
on public.company_members for select
using (
  company_id in (select company_id from public.company_members where user_id = auth.uid())
  or email = auth.jwt() ->> 'email'
);

-- Seul un Administrateur peut ajouter/modifier/supprimer des membres de son entreprise
create policy "Un administrateur gère les membres"
on public.company_members for all
using (
  company_id in (
    select company_id from public.company_members
    where user_id = auth.uid() and role = 'Administrateur'
  )
  or email = auth.jwt() ->> 'email'
)
with check (
  company_id in (
    select company_id from public.company_members
    where user_id = auth.uid() and role = 'Administrateur'
  )
  or email = auth.jwt() ->> 'email'
);

-- Lecture des données : tout membre de l'entreprise
create policy "Un membre lit les données de son entreprise"
on public.kv_store for select
using (
  company_id in (select company_id from public.company_members where user_id = auth.uid())
);

-- Écriture des données : Administrateur ou Éditeur uniquement (pas "Lecture seule")
create policy "Un éditeur ou administrateur modifie les données"
on public.kv_store for insert
with check (
  company_id in (
    select company_id from public.company_members
    where user_id = auth.uid() and role in ('Administrateur', 'Éditeur')
  )
);

create policy "Un éditeur ou administrateur met à jour les données"
on public.kv_store for update
using (
  company_id in (
    select company_id from public.company_members
    where user_id = auth.uid() and role in ('Administrateur', 'Éditeur')
  )
);

create policy "Un éditeur ou administrateur supprime les données"
on public.kv_store for delete
using (
  company_id in (
    select company_id from public.company_members
    where user_id = auth.uid() and role in ('Administrateur', 'Éditeur')
  )
);
