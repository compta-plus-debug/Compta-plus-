-- À exécuter une seule fois dans Supabase : tableau de bord → SQL Editor → coller → Run

create table if not exists public.kv_store (
  user_id uuid references auth.users(id) on delete cascade,
  key text not null,
  value text not null,
  updated_at timestamptz default now(),
  primary key (user_id, key)
);

alter table public.kv_store enable row level security;

-- Chaque utilisateur ne peut lire/écrire que ses propres données
create policy "Chaque utilisateur gère ses propres données"
on public.kv_store
for all
using (auth.uid() = user_id)
with check (auth.uid() = user_id);
